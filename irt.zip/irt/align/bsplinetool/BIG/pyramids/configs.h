
/*****************************************************************************
 *		Define some constants
 ****************************************************************************/
#undef		FALSE
#define		FALSE				((int)(0 != 0))
#undef		TRUE
#define		TRUE				(!FALSE)
#undef		ERROR
#define		ERROR				TRUE
#undef		PI
#define		PI					((double)3.14159265358979323846264338327950288419716939937510)


