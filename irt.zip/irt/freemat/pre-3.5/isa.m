function y = isa(x, type)
y = strcmp(typeof(x), type);
