function y = ndims(x)
y = length(size(x));
