function y = ischar(x)
y = strcmp(typeof(x), 'string');
