function y = notempty(x)
y = ~isempty(x);
