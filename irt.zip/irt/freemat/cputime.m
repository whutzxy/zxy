 function dummy = cputime
%function dummy = cputime
% needed for freemat 4.0

dummy = -1;
