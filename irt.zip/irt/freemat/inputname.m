 function out = inputname(varargin)
% needed for freemat 4.0
out = '?';
